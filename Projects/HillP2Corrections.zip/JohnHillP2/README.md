# John Hill IS 140 Project 2 

Contained in this folder is the starter code files as well as the requested updates from the textbook:  
-    *New perspectives on HTML and CSS3, 7th Edition, Tutorial 2, Case Problem 3* 

## Updates added: 
- Importing of css files and font links to the cw_class.html file 
- A complete style sheet overhaul was completed in cw_styles

## Sources: 
-  [Textbook](https://www.amazon.com/New-Perspectives-HTML5-CSS3-Comprehensive/dp/1305503937)
- Stack Overflow Article [CSS backround color not showing up](https://stackoverflow.com/questions/9751625/css-background-color-not-showing-up)